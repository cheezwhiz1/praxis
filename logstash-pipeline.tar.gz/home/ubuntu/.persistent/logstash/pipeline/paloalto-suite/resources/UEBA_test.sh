
##################################
######Log Based Password Guessing
##################################

 
# success login - creates the user
echo '2020-11-20T04:07:14.343Z 10.79.127.14 <14>Nov 19 22:07:14 FINDG-USRFW1.fincoad.com 1,2020/11/19 22:07:14,007901002308,SYSTEM,globalprotect,0,2020/11/19 22:07:14,,globalprotectgateway-regist-succ,GP_Gateway-N,0,0,general,informational,""GlobalProtect gateway user login succeeded. Login from: 98.15.132.218, Source region: US, User name: hummus@dfinsolutions.com, Client OS version: Microsoft Windows 10 Pro , 64-bit."",13308873,0x8000000000000000,0,0,0,0,,FINDG-USRFW1' | nc 127.0.0.1 9030

# exit(0)
sleep 2

n=1

# continue until $n equals 5
while [ $n -le 10 ]
do
	echo '2020-11-19T20:19:09.452Z 10.79.127.14 <14>Nov 19 14:19:09 FINDG-USRFW1.fincoad.com 1,2020/11/19 14:19:09,007901002308,SYSTEM,globalprotect,0,2020/11/19 14:19:09,,globalprotectgateway-regist-fail,GP_Gateway-N,0,0,general,informational,""GlobalProtect gateway user login failed. Login from: 73.79.233.15, Source region: US, User name: hummus@dfinsolutions.com, Client OS version: Microsoft Windows 10 Pro , 64-bit, error: Existing user session found."",13301109,0x8000000000000000,0,0,0,0,,FINDG-USRFW1' | nc 127.0.0.1 9030
	n=$(( n+1 ))	 # increments $n
	echo "sleeping 5 [sec]"
	sleep 5
done

#----------------------------------------------#

##################################
######Log Based Brute Force
##################################


echo '2020-11-20T04:07:14.343Z 10.79.127.14 <14>Nov 19 22:07:14 FINDG-USRFW1.fincoad.com 1,2020/11/19 22:07:14,007901002308,SYSTEM,globalprotect,0,2020/11/19 22:07:14,,globalprotectgateway-regist-succ,GP_Gateway-N,0,0,general,informational,""GlobalProtect gateway user login succeeded. Login from: 98.15.132.218, Source region: US, User name: hummus@dfinsolutions.com, Client OS version: Microsoft Windows 10 Pro , 64-bit."",13308873,0x8000000000000000,0,0,0,0,,FINDG-USRFW1' | nc 127.0.0.1 9030

# exit(0)
sleep 2

set n to 1
n=1

# continue until $n equals 5
while [ $n -le 20 ]
do
	echo '2020-11-19T20:19:09.452Z 10.79.127.14 <14>Nov 19 14:19:09 FINDG-USRFW1.fincoad.com 1,2020/11/19 14:19:09,007901002308,SYSTEM,globalprotect,0,2020/11/19 14:19:09,,globalprotectgateway-regist-fail,GP_Gateway-N,0,0,general,informational,""GlobalProtect gateway user login failed. Login from: 73.79.233.15, Source region: US, User name: hummus@dfinsolutions.com, Client OS version: Microsoft Windows 10 Pro , 64-bit, error: Existing user session found."",13301109,0x8000000000000000,0,0,0,0,,FINDG-USRFW1' | nc 127.0.0.1 9030
	n=$(( n+1 ))	 # increments $n
done

