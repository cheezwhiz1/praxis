host=10.6.8.169
port=5678
#port=9030
### Total Attaks: 19 (for now 15)
### 1 IPS, 3 AntiVirus , 11 custom

###############  IPS\IDS  ####################
#------------ vulnerability exploit detection, IPS\IDS ,(from sst) --------------
echo '<134>Jul  9 11:07:33 EXTPAN01 1,2025/07/09 11:07:33,012501001632,THREAT,vulnerability,2049,2025/07/09 11:07:33,10.107.151.222,204.74.248.12,75.141.3.1,204.74.248.12,VPN_UNTRUST,acuity\bkides,,web-browsing,vsys1,VPN-CLIENT,untrust-L3,ae2.3199,ae1.3050,Q1Radar,2025/07/09 11:07:33,2091092,1,62259,443,27216,443,0x81502000,tcp,alert,"api.loveswans.com/my/set-current-page",Microsoft Scripting Engine Memory Corruption Vulnerability(39108),dating,informational,client-to-server,6691696100468441366,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,1205045743386235170,,,1,,,,,,,,0,11,0,0,0,,EXTPAN01,,,,,0,,0,,N/A,info-leak,AppThreat-8168-5540,0x0,0,4294967295,' | nc  $host -u $port -q 0

###############  Custom  ####################
#------------ scan detection, secure web gateway , Network Service Scanning --------------
echo "<12>1 2025-11-30T23:02:21-06:00 PA-7050-1PP.ou.edu 1,2025/11/30 - - - 23:02:20,009908000353,THREAT,scan,2049,2025/11/30 23:02:20,10.195.13.12,129.15.0.138,0.0.0.0,0.0.0.0,,,,not-applicable,vsys7,TRUST_USER,UNTRUST_USER,ae1.521,,default,2025/11/30 23:02:20,0,1,41408,53,0,0,0x6000,udp,alert,"""",SCAN: Host Sweep(8002),any,medium,client-to-server,6848391753741883307,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,0,,,0,,,,,,,,0,11,0,0,0,VSYS_USER,PA-7050-1PP,,,,,0,,0,,N/A,scan,AppThreat-0-0,0x0,0,4294967295," | nc  $host -u $port -q 0
#------------ DNS Botnet signatures, secure web gateway , Command and Control --------------
######### missing ##########
#------------ spyware phone home detection, secure web gateway , Command and Control --------------
echo "<12>Nov 29 10:09:00 Panorama.lcsd.local 1,2025/11/29 10:09:00,012501006344,THREAT,spyware,2304,2025/11/29 10:08:55,10.2.58.11,192.33.14.30,204.109.64.2,192.33.14.30,DNS_out,,,dns,vsys1,inside,outside,ethernet1/21,ae1,Panorama,2025/11/29 10:08:55,8114841,1,53169,53,26300,53,0x80402000,udp,drop,"""",Bot: Torpig Phone Home DNS request(12657),any,medium,server-to-client,6874514491067774606,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,1206631431141373320,,,0,,,,,,,,0,12,0,0,0,,FW1,,,,,0,,0,,N/A,spyware,AppThreat-8348-6427,0x0,0,4294967295,,,f3c71e70-9216-45fc-bc0d-bd47a8584888,0" | nc  $host -u $port -q 0
#------------ flood detection, DDoS Protection fake , Network Denial of Service --------------
echo "<12>Nov 26 09:45:36 Panorama.lcsd.local 1,2025/11/26 09:45:36,012501006344,THREAT,spyware,2304,2025/11/26 09:45:28,192.168.65.51,10.2.59.11,0.0.0.0,0.0.0.0,DNS_dmz,,,dns,vsys1,dmz,inside,ethernet1/1,ethernet1/21,Panorama,2025/11/26 09:45:28,77069779,1,51033,53,0,0,0x80002000,udp,sinkhole,"""",ddos fake(8561),any,medium,client-to-server,6874514491023309456,0xa000000000000000,192.168.0.0-192.168.255.255,10.0.0.0-10.255.255.255,0,,1494861807293084620,,,0,,,,,,,,0,12,0,0,0,,FW1,,,,,0,,0,,N/A,dns-wildfire,AppThreat-7-51351,0x0,0,4294967295,,,3c7f73d1-2b5c-4088-b0e6-fc523b0b4078,0" | nc  $host -u $port -q 0
#------------ agent disable , disabling security tools --------------
echo '<134>Aug 23 14:03:33 SAUKGW1.acuity.com 1,2025/08/23 14:03:33,007901002498,SYSTEM,globalprotect,0,2025/08/23 14:03:33,,globalprotectgateway-agent-msg,SaukAcuity_Internal1,0,0,general,informational,"GlobalProtect gateway agent message. Login from: 10.100.6.237, User name: ebruk@acuity.com, Time: Fri Aug 23 14:03:33 2025., Message: Agent Disable, Comment: VPN Disable Empow Test. Override(s)=52",9901977,0x0,0,0,0,0,,SAUKGW1' | nc $host -u $port -q 0

###############  URL filtring (also custom) ####################
#------------ URL filtring fake, secure web gateway ,Command-and-Control, Command-and-Control --------------
echo '<134>Jul  9 11:07:33 EXTPAN01 1,2025/03/03 11:07:33,012501001632,THREAT,url,2049,2026/03/03 11:07:33,10.98.102.60,90.50.238.249,75.141.3.1,184.50.238.249,SvcImaging_OnlineStorage_Access,acuity\fkarls,,ssl,vsys1,Closets,untrust-L3,ae2.3103,ae1.3050,Q1Radar,2026/03/03 11:07:33,41504989,1,56704,443,39781,443,0x40b000,tcp,allow,"moprd-cdnservice-uw1.azureedge.net/",(9999),Command-and-Control,informational,client-to-server,6691696100468441026,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,0,,,0,,,,,,,,0,11,0,0,0,,EXTPAN01,,,,,0,,0,,N/A,unknown,AppThreat-0-0,0x0,0,4294967295,' | nc  $host -u $port -q 0
#------------ URL filtring fake, secure web gateway ,dynamic_dns, Command-and-Control --------------
echo '<134>Jul  9 11:07:33 EXTPAN01 1,2025/07/09 11:07:33,012501001632,THREAT,url,2049,2025/07/09 11:07:33,10.98.102.60,90.50.238.249,75.141.3.1,184.50.238.249,SvcImaging_OnlineStorage_Access,acuity\fkarls,,ssl,vsys1,Closets,untrust-L3,ae2.3103,ae1.3050,Q1Radar,2025/07/09 11:07:33,41504989,1,56704,443,39781,443,0x40b000,tcp,allow,"moprd-cdnservice-uw1.azureedge.net/",(9999),dynamic_dns,informational,client-to-server,6691696100468441026,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,0,,,0,,,,,,,,0,11,0,0,0,,EXTPAN01,,,,,0,,0,,N/A,unknown,AppThreat-0-0,0x0,0,4294967295,' | nc  $host -u $port -q 0
#------------ URL filtring fake, secure web gateway ,grayware, Drive-by Compromise --------------
echo '<134>Jul  9 11:07:33 EXTPAN01 1,2025/07/09 11:07:33,012501001632,THREAT,url,2049,2025/07/09 11:07:33,10.98.102.34,184.50.238.249,75.141.3.1,184.50.238.249,SvcImaging_OnlineStorage_Access,acuity\fkarls,,ssl,vsys1,Closets,untrust-L3,ae2.3103,ae1.3050,Q1Radar,2025/07/09 11:07:33,41504989,1,56704,443,39781,443,0x40b000,tcp,allow,"moprd-cdnservice-uw1.azureedge.net/",(9999),grayWare,informational,client-to-server,6691696100468441026,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,0,,,0,,,,,,,,0,11,0,0,0,,EXTPAN01,,,,,0,,0,,N/A,unknown,AppThreat-0-0,0x0,0,4294967295,' | nc  $host -u $port -q 0
#------------ URL filtring fake, secure web gateway ,hacking, Drive-by Compromise --------------
echo '<134>Jul  9 11:07:33 EXTPAN01 1,2025/07/09 11:07:33,012501001632,THREAT,url,2049,2025/07/09 11:07:33,10.98.102.34,184.50.238.249,75.141.3.1,184.50.238.249,SvcImaging_OnlineStorage_Access,acuity\fkarls,,ssl,vsys1,Closets,untrust-L3,ae2.3103,ae1.3050,Q1Radar,2025/07/09 11:07:33,41504989,1,56704,443,39781,443,0x40b000,tcp,allow,"moprd-cdnservice-uw1.azureedge.net/",(9999),hacking,informational,client-to-server,6691696100468441026,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,0,,,0,,,,,,,,0,11,0,0,0,,EXTPAN01,,,,,0,,0,,N/A,unknown,AppThreat-0-0,0x0,0,4294967295,' | nc  $host -u $port -q 0
#------------ URL filtring fake, secure web gateway ,malware, Drive-by Compromise --------------
echo '<134>Jul  9 11:07:33 EXTPAN01 1,2025/07/09 11:07:33,012501001632,THREAT,url,2049,2025/07/09 11:07:33,10.98.102.34,184.50.238.249,75.141.3.1,184.50.238.249,SvcImaging_OnlineStorage_Access,acuity\fkarls,,ssl,vsys1,Closets,untrust-L3,ae2.3103,ae1.3050,Q1Radar,2025/07/09 11:07:33,41504989,1,56704,443,39781,443,0x40b000,tcp,allow,"moprd-cdnservice-uw1.azureedge.net/",(9999),malware,informational,client-to-server,6691696100468441026,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,0,,,0,,,,,,,,0,11,0,0,0,,EXTPAN01,,,,,0,,0,,N/A,unknown,AppThreat-0-0,0x0,0,4294967295,' | nc  $host -u $port -q 0
#------------ URL filtring fake, secure web gateway ,phishing, Spearphishing Link --------------
echo '<134>Jul  9 11:07:33 EXTPAN01 1,2025/07/09 11:07:33,012501001632,THREAT,url,2049,2025/07/09 11:07:33,10.98.102.40,20.50.238.249,75.141.3.1,184.50.238.249,SvcImaging_OnlineStorage_Access,acuity\fkarls,,ssl,vsys1,Closets,untrust-L3,ae2.3103,ae1.3050,Q1Radar,2025/07/09 11:07:33,41504989,1,56704,443,39781,443,0x40b000,tcp,allow,"moprd-cdnservice-uw1.azureedge.net/",(9999),phishing,informational,client-to-server,6691696100468441026,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,0,,,0,,,,,,,,0,11,0,0,0,,EXTPAN01,,,,,0,,0,,N/A,unknown,AppThreat-0-0,0x0,0,4294967295,' | nc  $host -u $port -q 0
#------------ URL filtring fake, secure web gateway ,proxy avoidance and anonymizers, Multi-hop Proxy --------------
echo '<134>Jul  9 11:07:33 EXTPAN01 1,2025/07/09 11:07:33,012501001632,THREAT,url,2049,2025/07/09 11:07:33,10.98.102.50,180.50.238.249,75.141.3.1,184.50.238.249,SvcImaging_OnlineStorage_Access,acuity\fkarls,,ssl,vsys1,Closets,untrust-L3,ae2.3103,ae1.3050,Q1Radar,2025/07/09 11:07:33,41504989,1,56704,443,39781,443,0x40b000,tcp,allow,"moprd-cdnservice-uw1.azureedge.net/",(9999),proxy avoidance and anonymizers,informational,client-to-server,6691696100468441026,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,0,,,0,,,,,,,,0,11,0,0,0,,EXTPAN01,,,,,0,,0,,N/A,unknown,AppThreat-0-0,0x0,0,4294967295,' | nc  $host -u $port -q 0


###############  Anti-Virus  ####################
#------------ filetype detection, Anti-virus ,(from sst) --------------
host=10.6.8.169
port=5678
date1=$(date +"%+Y/%m/%d %H:%M:%S")
echo '<12>Sep 18 09:46:27 PA-VM 1,2025/04/18 09:46:26,007000000021583,THREAT,wildfire,0,'$date1',10.10.10.11,100.60.1.2,0.0.0.0,0.0.0.0,ips-test1,,,web-browsing,vsys1,tap,tap,ethernet1/5,ethernet1/5,panorama,/'$date1/',160557,1,80,53360,0,0,0x2000,tcp,allow,"Paper.pdf.exe",Windows Executable (EXE)(52025),malicious,high,server-to-client,1378735,0x8000000000000000,192.168.0.0-192.168.255.255,192.168.0.0-192.168.255.255,0,,0,534635117979678e6a48db21a20d8c065fbf2003fc58c8380131967c9537cad1,wildfire.paloaltonetworks.com,1,,pe,,,,,,11473430929,11,0,0,0,,PA-VM,,,,,0,,0,,N/A,unknown,WildFire-0-0,0x0' | nc  $host -u $port -q 0
#------------ Suspicious DNS Query detection, Anti-virus , (from sst) --------------
host=10.6.8.169
port=5678
echo "<12>Nov 30 06:52:21 Panorama.lcsd.local 1,2025/11/30 06:52:21,012501006344,THREAT,spyware,2304,2025/11/30 06:52:20,10.2.58.11,192.5.6.30,204.109.64.2,192.5.6.30,DNS_out,,,dns,vsys1,inside,outside,ethernet1/21,ae1,Panorama,2025/11/30 06:52:20,70153101,1,53080,53,47513,53,0x80402000,udp,sinkhole,"""",Suspicious DNS Query (generic:imp.wbxsearch.com)(387029133),any,medium,client-to-server,6874514491080290173,0xa000000000000000,10.0.0.0-10.255.255.255,United States,0,,1494861807293086055,,,0,,,,,,,,0,12,0,0,0,,FW1,,,,,0,,0,,N/A,dns,AppThreat-3547-4058,0x0,0,4294967295,,,f3c71e70-9216-45fc-bc0d-bd47a8584888,0" | nc  $host -u $port -q 0
#------------ wildfire DNS detection, Anti-virus , (from sst) --------------
echo "<12>Nov 26 09:45:36 Panorama.lcsd.local 1,2025/11/26 09:45:36,012501006344,THREAT,spyware,2304,2025/11/26 09:45:28,192.168.65.51,10.2.59.11,0.0.0.0,0.0.0.0,DNS_dmz,,,dns,vsys1,dmz,inside,ethernet1/1,ethernet1/21,Panorama,2025/11/26 09:45:28,77069779,1,51033,53,0,0,0x80002000,udp,sinkhole,"""",generic:daugia.org(385879728),any,medium,client-to-server,6874514491023309456,0xa000000000000000,192.168.0.0-192.168.255.255,10.0.0.0-10.255.255.255,0,,1494861807293084620,,,0,,,,,,,,0,12,0,0,0,,FW1,,,,,0,,0,,N/A,dns-wildfire,AppThreat-7-51351,0x0,0,4294967295,,,3c7f73d1-2b5c-4088-b0e6-fc523b0b4078,0" | nc  $host -u $port -q 0
#------------ virus detection, Anti-virus , (from sst) --------------
######### missing ##########
#------------ spyware download detection, Anti-virus , (from sst) --------------
######### missing ##########
#------------ wildFire signature feed, Anti-virus , (from sst) --------------
######### missing ##########

###############  UEBA  ####################

##################################
######Log Based Password Guessing
##################################

 
# success login - creates the user
echo '2025-11-20T04:07:14.343Z 10.79.127.14 <14>Nov 19 22:07:14 FINDG-USRFW1.fincoad.com 1,2025/11/19 22:07:14,007901002308,SYSTEM,globalprotect,0,2025/11/19 22:07:14,,globalprotectgateway-regist-succ,GP_Gateway-N,0,0,general,informational,""GlobalProtect gateway user login succeeded. Login from: 98.15.132.218, Source region: US, User name: hummus@dfinsolutions.com, Client OS version: Microsoft Windows 10 Pro , 64-bit."",13308873,0x8000000000000000,0,0,0,0,,FINDG-USRFW1' | nc $host -u $port -q 0

# exit(0)

n=1

# continue until $n equals 5
while [ $n -le 10 ]
do
	echo '2025-11-19T20:19:09.452Z 10.79.127.14 <14>Nov 19 14:19:09 FINDG-USRFW1.fincoad.com 1,2025/11/19 14:19:09,007901002308,SYSTEM,globalprotect,0,2025/11/19 14:19:09,,globalprotectgateway-regist-fail,GP_Gateway-N,0,0,general,informational,""GlobalProtect gateway user login failed. Login from: 73.79.233.15, Source region: US, User name: hummus@dfinsolutions.com, Client OS version: Microsoft Windows 10 Pro , 64-bit, error: Existing user session found."",13301109,0x8000000000000000,0,0,0,0,,FINDG-USRFW1' | nc $host -u $port -q 0
	n=$(( n+1 ))	 # increments $n
	echo "sleeping 0 [sec]"
	sleep 0
done

#----------------------------------------------#

##################################
######Log Based Brute Force
##################################


echo '2025-11-20T04:07:14.343Z 10.79.127.14 <14>Nov 19 22:07:14 FINDG-USRFW1.fincoad.com 1,2025/11/19 22:07:14,007901002308,SYSTEM,globalprotect,0,2025/11/19 22:07:14,,globalprotectgateway-regist-succ,GP_Gateway-N,0,0,general,informational,""GlobalProtect gateway user login succeeded. Login from: 98.15.132.218, Source region: US, User name: hummus@dfinsolutions.com, Client OS version: Microsoft Windows 10 Pro , 64-bit."",13308873,0x8000000000000000,0,0,0,0,,FINDG-USRFW1' | nc $host -u $port -q 0

# exit(0)

set n to 1
n=1

# continue until $n equals 5
while [ $n -le 20 ]
do
	echo '2025-11-19T20:19:09.452Z 10.79.127.14 <14>Nov 19 14:19:09 FINDG-USRFW1.fincoad.com 1,2025/11/19 14:19:09,007901002308,SYSTEM,globalprotect,0,2025/11/19 14:19:09,,globalprotectgateway-regist-fail,GP_Gateway-N,0,0,general,informational,""GlobalProtect gateway user login failed. Login from: 73.79.233.15, Source region: US, User name: hummus@dfinsolutions.com, Client OS version: Microsoft Windows 10 Pro , 64-bit, error: Existing user session found."",13301109,0x8000000000000000,0,0,0,0,,FINDG-USRFW1' | nc $host -u $port -q 0
	n=$(( n+1 ))	 # increments $n
done
