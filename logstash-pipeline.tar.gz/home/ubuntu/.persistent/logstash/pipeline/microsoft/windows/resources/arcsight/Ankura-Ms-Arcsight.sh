# # Microsoft-Windows-Security-Auditing:4624
# echo '{"System":{"EventId":"4624","Version":"2","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"dc-host","EventRecordID":"108654728","Keywords":"Audit Success","Level":"Information","Opcode":"Info","Task":"Logon","ProcessID":"828","ThreadID":"3780","TimeCreated":"1611707161482","UserId":""},"EventData":{"SubjectUserSid":"NULL SID","SubjectUserName":"-","SubjectDomainName":"-","SubjectLogonId":"0x0","TargetUserSid":"CLIENT\\\\\\\\computer-user$","TargetUserName":"computer-host","TargetDomainName":"client.domain","TargetLogonId":"0x0f59d1ab","LogonType":"3","LogonProcessName":"Kerberos","AuthenticationPackageName":"Kerberos","WorkstationName":"-","LogonGuid":"{62966b57-3e35-73b4-761b-93d0de0385e9}","TransmittedServices":"-","LmPackageName":"-","KeyLength":"0","ProcessId":"0x0","ProcessName":"-","IpAddress":"192.168.38.172","IpPort":"55652","ImpersonationLevel":"Impersonation","RestrictedAdminMode":"-","TargetOutboundUserName":"-","TargetOutboundDomainName":"-","VirtualAccount":"%%1843","TargetLinkedLogonId":"0x0","ElevatedToken":"%%1842"}}' | nc 127.0.0.1 9020
 
sleep 2
# Microsoft-Windows-Security-Auditing:4625
echo '{"System":{"EventId":"4625","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"dc-host","EventRecordID":"570037166","Keywords":"Audit Failure","Level":"Information","Opcode":"Info","Task":"Logon","ProcessID":"832","ThreadID":"8968","TimeCreated":"1611758576397","UserId":""},"EventData":{"SubjectUserSid":"NULL SID","SubjectUserName":"-","SubjectDomainName":"-","SubjectLogonId":"0x0","TargetUserSid":"NULL SID","TargetUserName":"computer-user","TargetDomainName":"client.domain","Status":"0xc000006d","FailureReason":"Unknown user name or bad password.","SubStatus":"0xc0000064","LogonType":"3","LogonProcessName":"NtLmSsp ","AuthenticationPackageName":"NTLM","WorkstationName":"computer-host","TransmittedServices":"-","LmPackageName":"-","KeyLength":"0","ProcessId":"0x0","ProcessName":"-","IpAddress":"192.168.38.173","IpPort":"61684"}}' | nc 127.0.0.1 9020
sleep 2
echo '{"System":{"EventId":"4625","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"DC.oz.land","EventRecordID":"7161473428","Keywords":"Audit Failure","Level":"Log Always","Opcode":"Info","Task":"Logon","ProcessID":"568","ThreadID":"7820","TimeCreated":"1613982549093","UserId":""},"EventData":{"SubjectUserSid":"NULL SID","SubjectUserName":"-","SubjectDomainName":"-","SubjectLogonId":"0x0","TargetUserSid":"NULL SID","TargetUserName":"gil","TargetDomainName":"oz","Status":"0xc000006d","FailureReason":"Unknown user name or bad password.","SubStatus":"0xc000006a","LogonType":"3","LogonProcessName":"NtLmSsp ","AuthenticationPackageName":"NTLM","WorkstationName":"WIN10-IT","TransmittedServices":"-","LmPackageName":"-","KeyLength":"0","ProcessId":"0x0","ProcessName":"-","IpAddress":"-","IpPort":"-"}}' | nc 127.0.0.1 9020
 
# sleep 2
# # Microsoft-Windows-Security-Auditing:4720
# echo '{"System":{"EventId":"4720","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"dc-host","EventRecordID":"564271169","Keywords":"Audit Success","Level":"Information","Opcode":"Info","Task":"User Account Management","ProcessID":"832","ThreadID":"1264","TimeCreated":"1611249608152","UserId":""},"EventData":{"TargetUserName":"user","TargetDomainName":"client.domain","TargetSid":"client.domain\\\\\\\\user","SubjectUserSid":"client.domain\\\\\\\\user","SubjectUserName":"user","SubjectDomainName":"client.domain","SubjectLogonId":"0x3a1e8e32","PrivilegeList":"-","SamAccountName":"user","DisplayName":"user_full_name","UserPrincipalName":"user_email","HomeDirectory":"-","HomePath":"-","ScriptPath":"-","ProfilePath":"-","UserWorkstations":"-","PasswordLastSet":"1/21/2021 12:20:08 PM","AccountExpires":"<never>","PrimaryGroupId":"513","AllowedToDelegateTo":"-","OldUacValue":"0x0","NewUacValue":"0x15","UserAccountControl":"Account Disabled|'Password Not Required' - Enabled|'Normal Account' - Enabled","UserParameters":"-","SidHistory":"-","LogonHours":"<value not set>"}}' | nc 127.0.0.1 9020
 
# sleep 2
# # Microsoft-Windows-Security-Auditing:4724
# echo '{"System":{"EventId":"4724","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"computer-host","EventRecordID":"4558387","Keywords":"Audit Success","Level":"Information","Opcode":"Info","Task":"User Account Management","ProcessID":"800","ThreadID":"2016","TimeCreated":"1611115098210","UserId":""},"EventData":{"TargetUserName":"Administrator","TargetDomainName":"computer-host","TargetSid":"S-1-5-21-2852629354-3964125154-4076514930-500","SubjectUserSid":"NT AUTHORITY\\\\\\\\SYSTEM","SubjectUserName":"computer-user$","SubjectDomainName":"client.domain","SubjectLogonId":"0x3e7"}}' | nc 127.0.0.1 9020

# sleep 2 
# # Microsoft-Windows-Security-Auditing:4728
# echo '{"System":{"EventId":"4728","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"dc-host","EventRecordID":"187786639","Keywords":"Audit Success","Level":"Information","Opcode":"Info","Task":"Security Group Management","ProcessID":"872","ThreadID":"3164","TimeCreated":"1611247958335","UserId":""},"EventData":{"MemberName":"CN\=user_full_name,OU\=Users,OU\=VSSP,DC\=client,DC\=domain","MemberSid":"client.domain\\\\\\\\user","TargetUserName":"user","TargetDomainName":"client.domain","TargetSid":"client.domain\\\\\\\\user","SubjectUserSid":"client.domain\\\\\\\\user","SubjectUserName":"user","SubjectDomainName":"client.domain","SubjectLogonId":"0x2d140c35","PrivilegeList":"-"}}' | nc 127.0.0.1 9020

# sleep 2
# echo '{"System":{"EventId":"4728","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"DC.oz.land","EventRecordID":"7161228503","Keywords":"Audit Success","Level":"Log Always","Opcode":"Info","Task":"Security Group Management","ProcessID":"568","ThreadID":"2772","TimeCreated":"1613982432055","UserId":""},"EventData":{"MemberName":"CN\=gil n,CN\=Users,DC\=oz,DC\=land","MemberSid":"OZ\\\\\\\\gil","TargetUserName":"Domain Admins","TargetDomainName":"OZ","TargetSid":"OZ\\\\\\\\Domain Admins","SubjectUserSid":"OZ\\\\\\\\Administrator","SubjectUserName":"administrator","SubjectDomainName":"OZ","SubjectLogonId":"0x1b3c294","PrivilegeList":"-"}}' | nc 127.0.0.1 9020

# sleep 2
# # Microsoft-Windows-Security-Auditing:4738
# echo '{"System":{"EventId":"4738","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"computer-host","EventRecordID":"4558386","Keywords":"Audit Success","Level":"Information","Opcode":"Info","Task":"User Account Management","ProcessID":"800","ThreadID":"2016","TimeCreated":"1611115098210","UserId":""},"EventData":{"Dummy":"-","TargetUserName":"Administrator","TargetDomainName":"dc-host","TargetSid":"S-1-5-21-2852629354-3964125154-4076514930-500","SubjectUserSid":"NT AUTHORITY\\\\\\\\SYSTEM","SubjectUserName":"dc-host$","SubjectDomainName":"client.domain","SubjectLogonId":"0x3e7","PrivilegeList":"-","SamAccountName":"Administrator","DisplayName":"<value not set>","UserPrincipalName":"-","HomeDirectory":"<value not set>","HomePath":"<value not set>","ScriptPath":"<value not set>","ProfilePath":"<value not set>","UserWorkstations":"<value not set>","PasswordLastSet":"1/19/2021 10:58:18 PM","AccountExpires":"<never>","PrimaryGroupId":"513","AllowedToDelegateTo":"-","OldUacValue":"0x210","NewUacValue":"0x210","UserAccountControl":"-","UserParameters":"-","SidHistory":"-","LogonHours":"All"}}' | nc 127.0.0.1 9020
 
# sleep 2
# # Microsoft-Windows-Security-Auditing:4740
# echo '{"System":{"EventId":"4740","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"COL-DC-03.vssp.local","EventRecordID":"569993733","Keywords":"Audit Success","Level":"Information","Opcode":"Info","Task":"User Account Management","ProcessID":"832","ThreadID":"7936","TimeCreated":"1611756031485","UserId":""},"EventData":{"TargetUserName":"user","TargetDomainName":"computer-host","TargetSid":"client.domain\\\\\\\\user","SubjectUserSid":"NT AUTHORITY\\\\\\\\SYSTEM","SubjectUserName":"dc-host$","SubjectDomainName":"client.domain","SubjectLogonId":"0x3e7"}}' | nc 127.0.0.1 9020

# sleep 2
# # Microsoft-Windows-Security-Auditing:4657
# echo '{"System":{"EventId":"4657","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"DC.oz.land","EventRecordID":"7158237432","Keywords":"Audit Success","Level":"Log Always","Opcode":"Info","Task":"Registry","ProcessID":"4","ThreadID":"88","TimeCreated":"1613980446868","UserId":""},"EventData":{"SubjectUserSid":"NT AUTHORITY\\\\\\\\SYSTEM","SubjectUserName":"DC$","SubjectDomainName":"OZ","SubjectLogonId":"0x3e7","ObjectName":"\\\\REGISTRY\\\\MACHINE\\\\SOFTWARE\\\\Wow6432Node\\\\TrendMicro\\\\OfficeScan\\\\service\\\\Outbreak_Alert","ObjectValueName":"Act_Failed_Query_Start_Time","HandleId":"0x51c","OperationType":"Existing registry value modified","OldValueType":"REG_DWORD","OldValue":"1613980385","NewValueType":"REG_DWORD","NewValue":"1613980445","ProcessId":"0xd58","ProcessName":"C:\\\\Program Files (x86)\\\\Trend Micro\\\\Security Server\\\\PCCSRV\\\\Web\\\\Service\\\\OfcService.exe"}}' | nc 127.0.0.1 9020

# sleep 2
# # Microsoft-Windows-Security-Auditing:4688
# echo '{"System":{"EventId":"4688","Version":"1","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"DC.oz.land","EventRecordID":"7159325446","Keywords":"Audit Success","Level":"Log Always","Opcode":"Info","Task":"Process Creation","ProcessID":"4","ThreadID":"84","TimeCreated":"1613981146760","UserId":""},"EventData":{"SubjectUserSid":"NT AUTHORITY\\\\\\\\SYSTEM","SubjectUserName":"DC$","SubjectDomainName":"OZ","SubjectLogonId":"0x3e7","NewProcessId":"0x299c","NewProcessName":"C:\\\\Program Files\\\\ATERA Networks\\\\AteraAgent\\\\Packages\\\\AgentPackageHeartbeat\\\\AgentPackageHeartbeat.exe","TokenElevationType":"TokenElevationTypeDefault (1)","ProcessId":"0x15e0","CommandLine":"\\"C:\\\\Program Files\\\\ATERA Networks\\\\AteraAgent\\\\Packages\\\\AgentPackageHeartbeat\\\\AgentPackageHeartbeat.exe\\" e33a5c20-c905-42b2-a773-dc8547ed0a11 \\"8fe706e7-990c-4fcb-a8ca-1ac8e2f03164\\" agent-api.atera.com/Production 443 or8ixLi90Mf \\"heartbeat\\""}}' | nc 127.0.0.1 9020

# sleep 2
# # Microsoft-Windows-Security-Auditing:4689
# echo '{"System":{"EventId":"4689","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"DC.oz.land","EventRecordID":"7159327336","Keywords":"Audit Success","Level":"Log Always","Opcode":"Info","Task":"Process Termination","ProcessID":"4","ThreadID":"92","TimeCreated":"1613981147909","UserId":""},"EventData":{"SubjectUserSid":"NT AUTHORITY\\\\\\\\SYSTEM","SubjectUserName":"DC$","SubjectDomainName":"OZ","SubjectLogonId":"0x3e7","Status":"0x0","ProcessId":"0xb50","ProcessName":"C:\\\\Windows\\\\System32\\\\conhost.exe"}}' | nc 127.0.0.1 9020













