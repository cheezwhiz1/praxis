#!/bin/bash

# This script is used for simulating UEBA brute force attack and password <user_name>  the attack to be connected to.
# you can choose any legal <user_name>. the default <user_name> is "passGuess_User".
# NOTE: 
#		1.the script is creating a user in the database by sending a successful login log 
#		2. if you want to see 2 different attacks in SST , close the first attack before running the second, otherwise they will be connected

result=""
res=0
UserName="passGuess_User"

function brute_force {

	let n=0

	#   10 times no sleeping
	while [ $n -lt 10 ]
	do
		echo "<Event xmlns='http://schemas.microsoft.com/win/2004/08/events/event'><System><Provider Name='Microsoft-Windows-Security-Auditing' Guid='{54849625-5478-4994-A5BA-3E3B0328C30D}'/><EventID>4624</EventID><Version>1</Version><Level>Information</Level><Task>Logon</Task><Opcode>Info</Opcode><Keywords>Audit Success</Keywords><TimeCreated SystemTime='2019-07-02T16:05:40.012703100Z'/><EventRecordID>90461516</EventRecordID><Correlation/><Execution ProcessID='612' ThreadID='5808'/><Channel>Security</Channel><Computer>FWPAXD-IWHP01.fincoad.com</Computer><Security/></System><EventData><Data Name='SubjectUserSid'>S-1-5-21-873128402-3342024598-2051005476-45320</Data><Data Name='SubjectUserName'>prod-pool-oneplace</Data><Data Name='SubjectDomainName'>FINCOAD</Data><Data Name='SubjectLogonId'>0x4e1c3</Data><Data Name='TargetUserSid'>S-1-5-21-873128402-3342024598-2051005476-52268</Data><Data Name='TargetUserName'>${UserName}</Data><Data Name='TargetDomainName'>FINCOAD</Data><Data Name='TargetLogonId'>0x90220b8c</Data><Data Name='LogonType'>2</Data><Data Name='LogonProcessName'>Advapi  </Data><Data Name='AuthenticationPackageName'>Negotiate</Data><Data Name='WorkstationName'>FWPAXD-IWHP01</Data><Data Name='LogonGuid'>{7F69578C-91AC-7937-C408-E1E2CA820F0A}</Data><Data Name='TransmittedServices'>-</Data><Data Name='LmPackageName'>-</Data><Data Name='KeyLength'>0</Data><Data Name='ProcessId'>0xdac</Data><Data Name='ProcessName'>C:\Windows\System32\inetsrv\w3wp.exe</Data><Data Name='IpAddress'>-</Data><Data Name='IpPort'>-</Data><Data Name='ImpersonationLevel'>%%1833</Data></EventData></Event>" | nc 192.168.1.172 9014
		let n++	 # increments $n
		echo $n	
	done	
	echo finished brute force
}


function pass_guess {
	let n=1

	#  10 times 7 sec difference
	while [ $n -le 10 ]
	do
		echo "<Event xmlns='http://schemas.microsoft.com/win/2004/08/events/event'><System><Provider Name='Microsoft-Windows-Security-Auditing' Guid='{54849625-5478-4994-A5BA-3E3B0328C30D}'/><EventID>4625</EventID><Version>0</Version><Level>Information</Level><Task>Logon</Task><Opcode>Info</Opcode><Keywords>Audit Failure</Keywords><TimeCreated SystemTime='2019-07-02T15:46:55.239693500Z'/><EventRecordID>4034863165</EventRecordID><Correlation/><Execution ProcessID='544' ThreadID='3832'/><Channel>Security</Channel><Computer>fwplan-dc01.fincoad.com</Computer><Security/></System><EventData><Data Name='SubjectUserSid'>NULL SID</Data><Data Name='SubjectUserName'>-</Data><Data Name='SubjectDomainName'>-</Data><Data Name='SubjectLogonId'>0x0</Data><Data Name='TargetUserSid'>NULL SID</Data><Data Name='TargetUserName'>${UserName}</Data><Data Name='TargetDomainName'>FINCOAD</Data><Data Name='Status'>0xc000006d</Data><Data Name='FailureReason'>%%2313</Data><Data Name='SubStatus'>0xc000006a</Data><Data Name='LogonType'>3</Data><Data Name='LogonProcessName'>NtLmSsp </Data><Data Name='AuthenticationPackageName'>NTLM</Data><Data Name='WorkstationName'>VDI-W7-PFL-0986</Data><Data Name='TransmittedServices'>-</Data><Data Name='LmPackageName'>-</Data><Data Name='KeyLength'>0</Data><Data Name='ProcessId'>0x0</Data><Data Name='ProcessName'>-</Data><Data Name='IpAddress'>10.234.176.35</Data><Data Name='IpPort'>52627</Data></EventData></Event>" | nc 192.168.1.172 9014
		let n++ 	 # increments $n
		echo "sleeping 7 [sec]"
		sleep 7
	done
	echo finished password guessing
}


function get_Y_or_N_from_user {
	let i=1
	while read -r -e    ;do
			answer=${REPLY,,} 
			len=${#answer}

			#make sure legal input
			if [ $len -eq 0 ]
				then
					continue
			fi


			#make sure legal input
			if [ ${answer} != 'y' ] && [ ${answer} != 'n' ] && [ ${answer} != 'yes' ] && [ ${answer} != 'no' ]  
			then
				echo "recived ${answer}. type yes or no only! ${i}/3"
				if [ $i == 3 ]
				then
					echo bye bye
					exit
				fi
			else 
				# answer=${REPLY,,}
				result=${answer}
				break
			fi
			let i++

	done < "${1:-/dev/stdin}"
	case  ${result} in 
	y*)
		res=1
		;;
	n*)
		res=0
		;;
	esac
}

echo 'creating username "passGuess_User". if you want another name type [y/n]'
get_Y_or_N_from_user



if [ $res -gt 0 ]
	then
		echo "Enter UserName:"
		read
		re="[[:space:]]+"
		# check if string is empty
		if [ ${#REPLY} -eq 0 ]
				then
					echo "Bad UserName"
					exit 
		fi

		# make sure legal user_name
		if [[ ${REPLY} =~ $re ]]
		then
			echo "Bad UserName"
			exit 
		fi
		UserName=${REPLY}
fi	


echo "user name is: $UserName"

# success login - creates the user
echo "<Event xmlns='http://schemas.microsoft.com/win/2004/08/events/event'><System><Provider Name='Microsoft-Windows-Security-Auditing' Guid='{54849625-5478-4994-A5BA-3E3B0328C30D}'/><EventID>4624</EventID><Version>1</Version><Level>Information</Level><Task>Logon</Task><Opcode>Info</Opcode><Keywords>Audit Success</Keywords><TimeCreated SystemTime='2019-07-02T16:05:40.012703100Z'/><EventRecordID>90461516</EventRecordID><Correlation/><Execution ProcessID='612' ThreadID='5808'/><Channel>Security</Channel><Computer>FWPAXD-IWHP01.fincoad.com</Computer><Security/></System><EventData><Data Name='SubjectUserSid'>S-1-5-21-873128402-3342024598-2051005476-45320</Data><Data Name='SubjectUserName'>prod-pool-oneplace</Data><Data Name='SubjectDomainName'>FINCOAD</Data><Data Name='SubjectLogonId'>0x4e1c3</Data><Data Name='TargetUserSid'>S-1-5-21-873128402-3342024598-2051005476-52268</Data><Data Name='TargetUserName'>${UserName}</Data><Data Name='TargetDomainName'>FINCOAD</Data><Data Name='TargetLogonId'>0x90220b8c</Data><Data Name='LogonType'>2</Data><Data Name='LogonProcessName'>Advapi  </Data><Data Name='AuthenticationPackageName'>Negotiate</Data><Data Name='WorkstationName'>FWPAXD-IWHP01</Data><Data Name='LogonGuid'>{7F69578C-91AC-7937-C408-E1E2CA820F0A}</Data><Data Name='TransmittedServices'>-</Data><Data Name='LmPackageName'>-</Data><Data Name='KeyLength'>0</Data><Data Name='ProcessId'>0xdac</Data><Data Name='ProcessName'>C:\Windows\System32\inetsrv\w3wp.exe</Data><Data Name='IpAddress'>-</Data><Data Name='IpPort'>-</Data><Data Name='ImpersonationLevel'>%%1833</Data></EventData></Event>" | nc 192.168.1.172 9014

sleep 2


##################################
######Log Based Password Guessing
##################################

echo "starting password Guessing ? type [y/n]"
get_Y_or_N_from_user

if [ $res -lt 1 ]
then
	echo "starting Log Based Brute Force ? type [y/n]"
	get_Y_or_N_from_user
	if [ $res -lt 1 ]
	then
		exit
	else 
		brute_force
		echo thank you for using Daniel Ben Hayon scrip for simulating UEBA event\'s!
		exit
	fi
fi

pass_guess
sleep 1
#----------------------------------------------#

#################################
#####Log Based Brute Force
#################################
echo "starting Log Based Brute Force ? "
get_Y_or_N_from_user

if [ $res -lt 1 ]
then
	echo thank you for using Daniel Ben Hayon scrip for simulating UEBA event\'s!
	exit
fi

brute_force

sleep 1

echo thank you for using Daniel Ben Hayon scrip for simulating UEBA event\'s!