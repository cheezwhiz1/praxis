#set a new user to test the parser and trigger event
TargetUserName="hummus"
EventRecordID=208000000

echo 'success login'
echo '{"System":{"EventId":"4624","Version":"2","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"dc-host","EventRecordID":"108654728","Keywords":"Audit Success","Level":"Information","Opcode":"Info","Task":"Logon","ProcessID":"828","ThreadID":"3780","TimeCreated":"1611707161482","UserId":""},"EventData":{"SubjectUserSid":"NULL SID","SubjectUserName":"-","SubjectDomainName":"-","SubjectLogonId":"0x0","TargetUserSid":"CLIENT\\\\\\\\computer-user$","TargetUserName":"'${TargetUserName}'","TargetDomainName":"client.domain","TargetLogonId":"0x0f59d1ab","LogonType":"3","LogonProcessName":"Kerberos","AuthenticationPackageName":"Kerberos","WorkstationName":"-","LogonGuid":"{62966b57-3e35-73b4-761b-93d0de0385e9}","TransmittedServices":"-","LmPackageName":"-","KeyLength":"0","ProcessId":"0x0","ProcessName":"-","IpAddress":"192.168.38.172","IpPort":"55652","ImpersonationLevel":"Impersonation","RestrictedAdminMode":"-","TargetOutboundUserName":"-","TargetOutboundDomainName":"-","VirtualAccount":"%%1843","TargetLinkedLogonId":"0x0","ElevatedToken":"%%1842"}}' | nc 127.0.0.1 9020

sleep 5

echo 'Stating Brute Force'
for i in {1..10}
do
	echo '{"System":{"EventId":"4625","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"dc-host","EventRecordID":"['${EventRecordID}']","Keywords":"Audit Failure","Level":"Information","Opcode":"Info","Task":"Logon","ProcessID":"832","ThreadID":"8968","TimeCreated":"1611758576397","UserId":""},"EventData":{"SubjectUserSid":"NULL SID","SubjectUserName":"-","SubjectDomainName":"-","SubjectLogonId":"0x0","TargetUserSid":"NULL SID","TargetUserName":"'${TargetUserName}'","TargetDomainName":"client.domain","Status":"0xc000006d","FailureReason":"Unknown user name or bad password.","SubStatus":"0xc0000064","LogonType":"3","LogonProcessName":"NtLmSsp ","AuthenticationPackageName":"NTLM","WorkstationName":"computer-host","TransmittedServices":"-","LmPackageName":"-","KeyLength":"0","ProcessId":"0x0","ProcessName":"-","IpAddress":"192.168.38.173","IpPort":"61684"}}' | nc 127.0.0.1 9020
	
	EventRecordID=$(( EventRecordID+1 ))
	
	sleep 1
done