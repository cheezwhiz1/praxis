# # Microsoft-Windows-Security-Auditing:4624
# echo '{"System":{"EventId":"4624","Version":"2","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"PDV01-ADDC-02.ProdJBC.com","EventRecordID":"604326555","Keywords":"Audit Success","Level":"Log Always","Opcode":"Info","Task":"Logon","ProcessID":"672","ThreadID":"3224","TimeCreated":"1616785442157","UserId":""},"EventData":{"SubjectUserSid":"NULL SID","SubjectUserName":"-","SubjectDomainName":"-","SubjectLogonId":"0x0","TargetUserSid":"PRODJBC\\DT-MJ08H3ZA$","TargetUserName":"DT-MJ08H3ZA$","TargetDomainName":"PRODJBC.COM","TargetLogonId":"0x39febfdb","LogonType":"3","LogonProcessName":"Kerberos","AuthenticationPackageName":"Kerberos","WorkstationName":"-","LogonGuid":"{46800DDC-F3DA-24F7-E422-728256BE759F}","TransmittedServices":"-","LmPackageName":"-","KeyLength":"0","ProcessId":"0x0","ProcessName":"-","IpAddress":"192.168.157.122","IpPort":"57196","ImpersonationLevel":"Impersonation","RestrictedAdminMode":"-","TargetOutboundUserName":"-","TargetOutboundDomainName":"-","VirtualAccount":"%%1843","TargetLinkedLogonId":"0x0","ElevatedToken":"%%1842"}}' | nc 127.0.0.1 9014

# # Microsoft-Windows-Security-Auditing:4625
echo '{"System":{"EventId":"4625","Version":"0","Channel":"Security","ProviderName":"Microsoft-Windows-Security-Auditing","Computer":"PDV01-ADDC-02.ProdJBC.com","EventRecordID":"604326487","Keywords":"Audit Failure","Level":"Log Always","Opcode":"Info","Task":"Logon","ProcessID":"672","ThreadID":"9868","TimeCreated":"1616785437314","UserId":""},"EventData":{"SubjectUserSid":"NULL SID","SubjectUserName":"-","SubjectDomainName":"-","SubjectLogonId":"0x0","TargetUserSid":"NULL SID","TargetUserName":"PDV02-UBJH-01$","TargetDomainName":"PRODJBC","Status":"0xc000006d","FailureReason":"Unknown user name or bad password.","SubStatus":"0xc000006a","LogonType":"3","LogonProcessName":"NtLmSsp ","AuthenticationPackageName":"NTLM","WorkstationName":"PDV02-UBJH-01","TransmittedServices":"-","LmPackageName":"-","KeyLength":"0","ProcessId":"0x0","ProcessName":"-","IpAddress":"10.20.234.25","IpPort":"33636"}}' | nc 127.0.0.1 9014








