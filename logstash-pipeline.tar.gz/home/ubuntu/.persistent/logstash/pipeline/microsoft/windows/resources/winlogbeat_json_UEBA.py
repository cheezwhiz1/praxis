#!/usr/bin/env python3

# to use this script run ./winlogbeat_ueba_simulator 

import socket
import json
import time

# HOST = "127.0.0.1"  # The server's hostname or IP address
# PORT = 44144        # The port used by the server

HOST = "192.168.1.172"  # The server's hostname or IP address
PORT = 9014             # The port used by the server



def create_log4625(TargetUserName,record_id):
	log_4625={"log":{"level":"information"},"@version":"1","message":"An account failed to log on.\n\nSubject:\n\tSecurity ID:\t\tS-1-0-0\n\tAccount Name:\t\t-\n\tAccount Domain:\t\t-\n\tLogon ID:\t\t0x0\n\nLogon Type:\t\t\t3\n\nAccount For Which Logon Failed:\n\tSecurity ID:\t\tS-1-0-0\n\tAccount Name:\t\tGlinda\n\tAccount Domain:\t\tOZ\n\nFailure Information:\n\tFailure Reason:\t\tUnknown user name or bad password.\n\tStatus:\t\t\t0xc000006d\n\tSub Status:\t\t0xc000006a\n\nProcess Information:\n\tCaller Process ID:\t0x0\n\tCaller Process Name:\t-\n\nNetwork Information:\n\tWorkstation Name:\tMUNCHKINLAND\n\tSource Network Address:\t-\n\tSource Port:\t\t-\n\nDetailed Authentication Information:\n\tLogon Process:\t\tNtLmSsp \n\tAuthentication Package:\tNTLM\n\tTransited Services:\t-\n\tPackage Name (NTLM only):\t-\n\tKey Length:\t\t0\n\nThis event is generated when a logon request fails. It is generated on the computer where access was attempted.\n\nThe Subject fields indicate the account on the local system which requested the logon. This is most commonly a service such as the Server service, or a local process such as Winlogon.exe or Services.exe.\n\nThe Logon Type field indicates the kind of logon that was requested. The most common types are 2 (interactive) and 3 (network).\n\nThe Process Information fields indicate which account and process on the system requested the logon.\n\nThe Network Information fields indicate where a remote logon request originated. Workstation name is not always available and may be left blank in some cases.\n\nThe authentication information fields provide detailed information about this specific logon request.\n\t- Transited services indicate which intermediate services have participated in this logon request.\n\t- Package name indicates which sub-protocol was used among the NTLM protocols.\n\t- Key length indicates the length of the generated session key. This will be 0 if no session key was requested.","tags":["beats_input_codec_plain_applied"],"event":{"action":"Logon","code":4625,"created":"2019-04-15T07:36:30.603Z","kind":"event"},"ecs":{"version":"1.0.0"},"winlog":{"channel":"Security","event_id":4625,"keywords":["Audit Failure"],"computer_name":"DC.oz.land","opcode":"Info","api":"wineventlog","provider_guid":"{54849625-5478-4994-A5BA-3E3B0328C30D}","task":"Logon","record_id":record_id,"event_data":{"ProcessId":"0x0","AuthenticationPackageName":"NTLM","IpPort":"-","FailureReason":"%%2313","LogonType":"3","TransmittedServices":"-","SubjectLogonId":"0x0","Status":"0xc000006d","LmPackageName":"-","LogonProcessName":"NtLmSsp ","KeyLength":"0","SubjectUserName":"-","IpAddress":"-","ProcessName":"-","TargetUserSid":"S-1-0-0","SubjectDomainName":"-","WorkstationName":"MUNCHKINLAND","TargetUserName":"testush9000","SubjectUserSid":"S-1-0-0","SubStatus":"0xc0sad6a","TargetDomainName":"OZ"},"provider_name":"Microsoft-Windows-Security-Auditing","process":{"thread":{"id":5436},"pid":544}},"agent":{"ephemeral_id":"93ee4af5-130a-457c-a620-b92afecf29a7","hostname":"DC","id":"6dcb5c11-fa40-4cac-bc3c-ecab8952390b","version":"7.0.0","type":"winlogbeat"},"host":{"hostname":"DC","id":"2b0a2bd9-edaf-45cc-8c97-9ddc5c184da3","name":"DC","architecture":"x86_64","os":{"platform":"windows","kernel":"6.1.7601.23889 (win7sp1_ldr.170810-1615)","build":"7601.23907","version":"6.1","family":"windows","name":"Windows Server 2008 R2 Enterprise"}}}
	log_4625=json.dumps(log_4625)
	return log_4625


def create_user(TargetUserName,record_id):
	log_4624=json.dumps({"tags":["beats_input_codec_plain_applied"],"message":"An account was successfully logged on.\n\nSubject:\n\tSecurity ID:\t\tS-1-5-18\n\tAccount Name:\t\tDC$\n\tAccount Domain:\t\tOZ\n\tLogon ID:\t\t0x3e7\n\nLogon Type:\t\t\t10\n\nNew Logon:\n\tSecurity ID:\t\tS-1-5-21-2521481594-3673023198-3481644760-1182\n\tAccount Name:\t\tskeeter\n\tAccount Domain:\t\tOZ\n\tLogon ID:\t\t0x1d1751c6\n\tLogon GUID:\t\t{00000000-0000-0000-0000-000000000000}\n\nProcess Information:\n\tProcess ID:\t\t0x1b08\n\tProcess Name:\t\tC:\\Windows\\System32\\winlogon.exe\n\nNetwork Information:\n\tWorkstation Name:\tDC\n\tSource Network Address:\t192.168.1.122\n\tSource Port:\t\t52528\n\nDetailed Authentication Information:\n\tLogon Process:\t\tUser32 \n\tAuthentication Package:\tNegotiate\n\tTransited Services:\t-\n\tPackage Name (NTLM only):\t-\n\tKey Length:\t\t0\n\nThis event is generated when a logon session is created. It is generated on the computer that was accessed.\n\nThe subject fields indicate the account on the local system which requested the logon. This is most commonly a service such as the Server service, or a local process such as Winlogon.exe or Services.exe.\n\nThe logon type field indicates the kind of logon that occurred. The most common types are 2 (interactive) and 3 (network).\n\nThe New Logon fields indicate the account for whom the new logon was created, i.e. the account that was logged on.\n\nThe network fields indicate where a remote logon request originated. Workstation name is not always available and may be left blank in some cases.\n\nThe authentication information fields provide detailed information about this specific logon request.\n\t- Logon GUID is a unique identifier that can be used to correlate this event with a KDC event.\n\t- Transited services indicate which intermediate services have participated in this logon request.\n\t- Package name indicates which sub-protocol was used among the NTLM protocols.\n\t- Key length indicates the length of the generated session key. This will be 0 if no session key was requested.","agent":{"ephemeral_id":"b1bb6fda-935d-46ab-a66c-37c47e8d94e2","type":"winlogbeat","version":"7.0.0","hostname":"DC","id":"6dcb5c11-fa40-4cac-bc3c-ecab8952390b"},"type":"beats","event":{"action":"Logon","created":"2019-10-17T10:35:12.257Z","code":4624,"kind":"event"},"log":{"level":"information"},"winlog":{"task":"Logon","keywords":["Audit Success"],"provider_guid":"{54849625-5478-4994-A5BA-3E3B0328C30D}","computer_name":"DC.oz.land","channel":"Security","event_id":4624,"provider_name":"Microsoft-Windows-Security-Auditing","record_id":record_id,"opcode":"Info","api":"wineventlog","process":{"thread":{"id":7532},"pid":544},"event_data":{"WorkstationName":"DC","ProcessId":"0x1b08","TargetUserSid":"S-1-5-21-2521481594-3673023198-3481644760-1182","TargetDomainName":"OZ","SubjectUserName":"DC$","SubjectDomainName":"OZ","TargetUserName":TargetUserName,"IpAddress":"192.168.1.122","TargetLogonId":"0x1d1751c6","ProcessName":"C:\\Windows\\System32\\winlogon.exe","LogonProcessName":"User32 ","AuthenticationPackageName":"Negotiate","KeyLength":"0","SubjectUserSid":"S-1-5-18","LogonType":"10","LogonGuid":"{00000000-0000-0000-0000-000000000000}","TransmittedServices":"-","SubjectLogonId":"0x3e7","LmPackageName":"-","IpPort":"52528"}},"ecs":{"version":"1.0.0"},"@version":"1","host":{"id":"2b0a2bd9-edaf-45cc-8c97-9ddc5c184da3","name":"DC","architecture":"x86_64","hostname":"DC","os":{"build":"7601.24465","name":"Windows Server 2008 R2 Enterprise","version":"6.1","kernel":"6.1.7601.24444 (win7sp1_ldr_escrow.190429-1700)","platform":"windows","family":"windows"}}})
	with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
		s.connect((HOST, PORT))		
		s.sendall(bytes(log_4624,encoding='utf-8'))
	return log_4624

def brute_force(TargetUserName):
	for i in range(10):
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.connect((HOST, PORT))
		log_4625=create_log4625(TargetUserName,i)			
		s.sendall(bytes(log_4625,encoding='utf-8'))
		s.close()
	print("Finished brute force")



def pass_guess(TargetUserName):
	for i in range(10):
		s =  socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
		s.connect((HOST, PORT))
		log_4625=create_log4625(TargetUserName,i)
		# print(log_4625)
		s.sendall(log_4625.encode(('utf-8')))
		time.sleep(3)
		s.close()
		print("sleeping 3 [sec]")

	print("password guessing")



def get_YN_answer():
	yes = {'yes','y', 'ye', ''}
	no = {'no','n'}
	
	choice = input().lower()
	if choice in yes:
   		return True
	elif choice in no:
   		return False
	else:
   		print("Please respond with 'yes' or 'no'")
   		exit()


def get_user_name():
 	res=input("Enter UserName:").lower()
 	return res



if __name__ == "__main__":

	# record_id=1
	TargetUserName=''
	print("creating user name \"generic_User\". if you want another name type [yes/no]")
	answer=get_YN_answer()
	if (answer):
		TargetUserName=get_user_name()
	else:
		TargetUserName="generic_User"

	print("sending successful login. User Name is: ",TargetUserName)
	#create user
	create_user(TargetUserName,9)
	#password guessing
	print("start password Guessing  type [yes/no]")
	answer=get_YN_answer()
	if (answer):
		pass_guess(TargetUserName)
	
	#brute_force
	print("start Log Based Brute Force ? type [yes/no]")
	answer=get_YN_answer()
	if (answer):
		brute_force(TargetUserName)

